#include "CPID.h"

PID::PID(float kp, float ki, float kd, float outMin, float outMax) 
: _kp(kp) , _ki(ki), _kd(kd), _outMin(outMin), _outMax(outMax){}

void PID::setGains(float kp, float ki, float kd){
    _kp = kp;
    _ki = ki;
    _kd = kd;
}

void PID::setLimits(float outMin, float outMax){
    _outMin = outMin;
    _outMax = outMax;
}

void PID::reset(){
    _integral = 0.0f;
    _prevIn = 0.0f;
    _prevTime = 0;
    _initialized = false;
}

float PID::update(float curr, float setpoint){
    unsigned long currTime = micros();
    if(!_initialized){
        _prevIn = curr;
        _prevTime = currTime;
        _initialized = true;
        return(0.0f);
    } else{
        float dt = (currTime - _prevTime)*1e-6f;
        _prevTime = currTime;
        return update(curr, setpoint, dt);
    }
    
}

float PID::update(float curr, float setpoint, float dt){
    if(dt <= 0.0f){return 0.0f;}
    _prevTime = micros();
    if(!_initialized){
        _prevIn = curr;
        _initialized = true;
        return(0.0f);
    } else{
        float error = setpoint - curr;
        float derivative = (curr-_prevIn)/dt;
        float integralCalc = _integral + (error*dt);
        float output = error * _kp + integralCalc * _ki - derivative * _kd;
        if(output > _outMax){
            output = _outMax; //clamp output
            if(error < 0){_integral = integralCalc;} //prevent integral wind up with output saturation
        } else if(output < _outMin){
            output = _outMin; //clamp output
            if(error > 0){_integral = integralCalc;} //prevent integral wind up with output saturation
        } else{
            _integral = integralCalc;
        }
        _prevIn = curr;
        return output;
    }
}