#pragma once
#include <Arduino.h>

class PID{
    protected:
        float _kp, _ki, _kd;
        float _integral = 0.0f;
        float _prevIn = 0.0f;
        unsigned long _prevTime = 0;
        float _outMin, _outMax;
        bool _initialized = false;

    public:
       PID(float kp, float ki, float kd, float outMin, float outMax);
       void setGains(float kp, float ki, float kd);
       void setLimits(float outMin, float outMax);
       void reset();
       float update(float curr, float setpoint);
       float update(float curr, float setpoint, float dt); //in microseconds
};